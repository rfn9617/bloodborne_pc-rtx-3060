Изменения для Windows / RTX 3060 6 ГБ / i7-11800H / 32 ГБ RAM.
Это исходный патч и инструкция сборки. Готовых Windows .exe в архиве нет.
Исходная ветка: rfn9617/bloodborne_pc-rtx-3060, windows.
Проверенная базовая версия: ec7ee785ecafeeaea102d56be7d7bc1b54ca0cf8

В облачном рабочем репозитории изменения уже применены.
Для переноса на свой Windows-компьютер: распакуйте changes.patch в корень
копии исходного репозитория и выполните сначала git apply --check changes.patch,
затем git apply changes.patch. Не применяйте патч повторно и не сбрасывайте
локальные изменения. Если проверка не проходит, требуется согласование с вашей
версией исходников.

Сборка: MSYS2 CLANG64 и зависимости по packaging/windows/README.md.
Мост DLSS: MSVC 2022 и официальный NVIDIA DLSS SDK.

  git submodule update --init --recursive
  BB_LTO=OFF bash build.sh
  DLSS_SDK_ROOT=F:/sdk/DLSS bash packaging/windows/build_dlss.sh
  bash packaging/windows/package.sh --profile rtx3060-6gb --minimal

Результат: dist/bbport-windows-rtx3060-6gb.zip.
Профиль: Full HD / DLSS K Quality / 72 FPS; увеличены RAM-буферы загрузки.
Для существующих настроек используйте кнопку применения профиля в лаунчере.

Проверки в Linux: 64 Python-теста прошли, 25 пропущены; четыре новые C++-проверки
прошли (alpha detail, возраст кеша, запас RAM без удержания VRAM, настоящая
сериализация метаданных шейдера). Со старым расположением has_discard последний
тест воспроизводит ошибку. Изменённые файлы Vulkan проверены компилятором.
Тест удаления GPU-копий добавлен в tests/test_scene_resolution.cpp, но не выполнен:
GPU и полной сборки здесь нет. Windows EXE, изображение и стабильность кадров
на RTX 3060 требуют проверки на вашем ПК. Смотрите RTX3060-6GB.md.
